<footer>
    <p>&copy; <?php echo date('Y'); ?> Medical in Between & Coaching</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>