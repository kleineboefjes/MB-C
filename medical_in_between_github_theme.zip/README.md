# Medical in Between & Coaching – WordPress Theme

Dit is een eenvoudig, strak en professioneel WordPress-thema ontworpen voor medische cursussen en coaching. Het is opgebouwd in blauwe stijl en bevat een homepage, navigatie, stijlen en basisfuncties.

## Inhoud

- `style.css` – Thema-informatie en opmaak
- `index.php` – Homepage-inhoud
- `header.php` & `footer.php` – Paginaopbouw
- `functions.php` – Laadt stylesheets

## Installatie

1. Download deze repository als ZIP
2. Upload de ZIP via het WordPress-dashboard onder **Weergave > Thema’s > Nieuwe toevoegen > Thema uploaden**
3. Activeer het thema

## Demo

![Voorbeeld homepage](screenshot.png)

## Licentie

GPL v2 of later.
