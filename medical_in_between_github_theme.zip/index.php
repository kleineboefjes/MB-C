<?php get_header(); ?>
<main>
    <h2>Welkom bij Medical in Between & Coaching</h2>
    <p>Wij bieden geaccrediteerde medische cursussen en persoonlijke coaching voor zorgprofessionals.</p>
    <a class="button" href="#">Bekijk cursussen</a>
</main>
<?php get_footer(); ?>