<?php
function medical_in_between_scripts() {
    wp_enqueue_style('style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'medical_in_between_scripts');
?>